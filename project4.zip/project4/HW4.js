/* @author : Bhushan Jain*/
/* @andrewId : bhushanj@andrew.cmu.edu*/
/* Description : JS created for HW4 : 08724 Client Side */
function contentFetch(id) { 
$.getJSON("http://csw08724.appspot.com/breed.ajax",{"id": id})
.done(function(dogValuesData){
//$("#descriptions").text(dogValuesData.desc);   
$("#origins").text(dogValuesData.origins);
$("#rightForYou").text(dogValuesData.rightForYou);
$("#breed-name").text(dogValuesData.name);
//$("#descriptions").text(dogValuesData.desc);
$("#description").text(dogValuesData.description);
$(".content_right").empty();
var dogImgUrls = "http://csw08724.appspot.com/";
$("<img>",{
"src": dogImgUrls + dogValuesData.imageUrls
}).appendTo($(".content_right"));
// console.log(dogValuesData.dogImgUrls);
// window.alert(dogValuesData) -- undefined ???
$.each(dogValuesData.imageUrls, function(i, dogIds) {
$("<img>",{"src": dogImgUrls + dogIds
}).appendTo($(".content_right")); 
});
var itr=0;
var values_dog = document.querySelector('.content_right');
var test_dogbreed 
= values_dog.querySelectorAll(':not(:first-child)');
for (itr=0; itr < test_dogbreed.length; itr++) {
test_dogbreed[itr].classList.add('is-hidden');
//	src = "http://csw08724.appspot.com/" + values_dog.imageUrls[1];
//		src = "http://csw08724.appspot.com/" + values_dog.imageUrls[2];
//	src = "http://csw08724.appspot.com/" + values_dog.imageUrls[3];
//src = "http://csw08724.appspot.com/" + values_dog.imageUrls[4];
}
values_dog.addEventListener('transitionend', function() {     
values_dog.insertBefore(values_dog.querySelector(':first-child.is-hidden'), null);
});
//setting time interval for image slide show
setInterval(function() {
values_dog.querySelector(':first-child').classList.add('is-hidden');
// values_dog.querySelector(':last-child').classList.add('is-hidden');
values_dog.querySelector(':nth-child(2)').classList.remove('is-hidden');
 }, 5001)
 });
 }
$(function() { $(document).ready(function() {   
$.getJSON("http://csw08724.appspot.com/breeds.ajax", function(dogValuesData){
$.each(dogValuesData, function(i, dogIds){
$("<option></option>", {
//options
"id": dogIds.id,
"value": dogIds.id,
//id  value and name
text: dogIds.name
}).appendTo("#select");
});
contentFetch(1);
$("#select").on("change", function(event) {
contentFetch(event.target.value);
});  });
});

});
